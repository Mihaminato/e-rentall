<template>
  <div class="menu p-4 w-80 min-h-full bg-base-100 text-base-content">
    <!-- Profil admin -->
    <AdminProfile />

    <!-- Navigation -->
    <AdminNavigation />
  </div>
</template>

<script setup lang="ts">
  // Composant sidebar admin
</script>
