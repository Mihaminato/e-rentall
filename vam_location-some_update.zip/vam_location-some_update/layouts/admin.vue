<template>
  <div class="min-h-screen bg-base-200">
    <AdminDrawer>
      <slot></slot>
    </AdminDrawer>
  </div>
</template>
