<template>
  <div>
    <h1>Privacy</h1>
  </div>
</template>
