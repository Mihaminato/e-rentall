<template>
  <div>
    <h1>À propos</h1>
  </div>
</template>
