<template>
  <div class="container mx-auto px-4 py-12">
    <div class="max-w-4xl mx-auto">
      <h1 class="text-3xl font-bold mb-8">Conditions d'utilisation</h1>
      
      <div class="prose prose-lg">
        <p class="mb-6">Dernière mise à jour : 24 juin 2025</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">1. Acceptation des conditions</h2>
        <p>En accédant et en utilisant notre plateforme de location de véhicules entre particuliers, vous acceptez d'être lié par les présentes conditions d'utilisation. Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser notre service.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">2. Description du service</h2>
        <p>Notre plateforme permet la mise en relation entre propriétaires de véhicules et locataires potentiels pour des locations de courte durée. Nous ne sommes pas propriétaires des véhicules proposés à la location et n'agissons qu'en tant qu'intermédiaire.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">3. Inscription et compte utilisateur</h2>
        <p>Pour utiliser pleinement notre service, vous devez créer un compte utilisateur avec des informations exactes, complètes et à jour. Vous êtes responsable de la confidentialité de votre mot de passe et de toutes les activités effectuées sous votre compte.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">4. Conditions pour les propriétaires</h2>
        <p>En tant que propriétaire proposant un véhicule à la location :</p>
        <ul class="list-disc pl-6 mb-6">
          <li>Vous garantissez être le propriétaire légal du véhicule ou avoir l'autorisation de le mettre en location</li>
          <li>Vous garantissez que le véhicule est en bon état de fonctionnement, conforme aux normes de sécurité et régulièrement entretenu</li>
          <li>Vous devez fournir des informations exactes et complètes sur votre véhicule</li>
          <li>Vous acceptez de respecter vos engagements envers les locataires</li>
        </ul>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">5. Conditions pour les locataires</h2>
        <p>En tant que locataire d'un véhicule sur notre plateforme :</p>
        <ul class="list-disc pl-6 mb-6">
          <li>Vous devez posséder un permis de conduire valide et répondre aux conditions légales pour conduire le véhicule loué</li>
          <li>Vous vous engagez à utiliser le véhicule conformément aux lois en vigueur et aux indications du propriétaire</li>
          <li>Vous êtes responsable du véhicule pendant la durée de la location</li>
          <li>Vous vous engagez à respecter les horaires de prise en charge et de restitution convenus</li>
        </ul>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">6. Réservations et paiements</h2>
        <p>Les réservations sont soumises à l'approbation des propriétaires. Le paiement est sécurisé et traité via notre plateforme. Les annulations sont soumises à notre politique d'annulation en vigueur au moment de la réservation.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">7. Assurance</h2>
        <p>Notre plateforme inclut une couverture d'assurance pour les locations effectuées via notre service, selon les conditions détaillées dans notre document de politique d'assurance. Les utilisateurs doivent prendre connaissance des modalités précises et des exclusions.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">8. Limitation de responsabilité</h2>
        <p>Dans toute la mesure permise par la loi applicable, notre responsabilité est limitée. Nous ne sommes pas responsables des dommages indirects, consécutifs ou punitifs résultant de l'utilisation de notre service ou des transactions entre utilisateurs.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">9. Modification des conditions</h2>
        <p>Nous nous réservons le droit de modifier ces conditions à tout moment. Les modifications prennent effet dès leur publication sur notre plateforme. Il est de votre responsabilité de consulter régulièrement ces conditions.</p>
        
        <h2 class="text-2xl font-semibold mt-8 mb-4">10. Droit applicable et juridiction compétente</h2>
        <p>Ces conditions sont régies par le droit français. Tout litige relatif à leur interprétation ou exécution relève des tribunaux compétents.</p>
        
        <div class="bg-base-200 p-6 rounded-lg mt-12">
          <p class="font-semibold">Contact</p>
          <p>Pour toute question concernant ces conditions d'utilisation, veuillez nous contacter à :</p>
          <p class="mt-2">contact@carrental.com</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// Aucune logique spécifique n'est nécessaire pour cette page statique
// Ce contenu est un modèle de base qui pourra être personnalisé ultérieurement
</script>
